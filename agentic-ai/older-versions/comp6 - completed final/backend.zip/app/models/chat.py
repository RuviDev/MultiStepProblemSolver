from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime

class ChatUIAState(BaseModel):
    chat_id: str
    employment_category_id: Optional[str] = None
    skills_selected: Optional[List[str]] = None
    let_system_decide: bool = False
    vault_version: str
    recorded_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
