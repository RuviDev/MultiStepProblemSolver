# intent_llm.py
import json
from typing import Tuple
from app.core.openai_client import client, DEFAULT_MODEL, REQUEST_TIMEOUT

# SYSTEM_PROMPT = (
#     "You are a precise boolean classifier for chat messages.\n"
#     "Return ONLY a JSON object complying with the provided JSON Schema.\n"
#     "Definitions:\n"
#     "- employment_intent: true if the message describes, names, or implies the user's job/role/category; false otherwise.\n"
#     "- skills_intent: true if the message asks about learning, choosing, improving, or prioritizing skills; false otherwise.\n"
#     "Never guess based on profile or prior chats—use the current message only."
# )

# INTENT_SCHEMA = {
#     "name": "UIAIntent",
#     "schema": {
#         "type": "object",
#         "additionalProperties": False,
#         "properties": {
#             "employment_intent": {"type": "boolean"},
#             "skills_intent": {"type": "boolean"},
#             "confidence": {"type": "number", "minimum": 0, "maximum": 1}
#         },
#         "required": ["employment_intent", "skills_intent", "confidence"]
#     },
#     "strict": True
# }
SYSTEM_PROMPT = (
    "You are a precise boolean classifier for a single chat message.\n"
    "Return ONLY a JSON object that conforms to the provided JSON Schema.\n"
    "\n"
    "Definitions:\n"
    "- employment_intent: true if the message describes, names, or implies the user's job/role/category; false otherwise.\n"
    
    "- skills_intent: true only if the message asks to choose, prioritize, or improve **skills**, or requests a skill plan/roadmap/course.\n"
      "Examples: “which skills should I learn”, “help me pick 4 skills”, “how do I improve my SQL skill”, “make me a learning roadmap”.\n"
    "- skills_intent: false for general explanations, definitions, or overviews of a field (e.g., “explain data science”, “what is data science”).\n"
    
    "- ec_hit: set to 'ec_ds' ONLY if the message explicitly mentions a Data Scientist role/title.\n"
    "  Treat these as explicit mentions (examples, not exhaustive):\n"
    "  'data scientist', 'senior data scientist', 'lead data scientist',\n"
    "  'ml/data scientist', 'machine learning scientist' (as a role),\n"
    "  'i am a data scientist', 'i work as a data scientist', etc.\n"
    "  Do NOT set ec_hit when the text only references data science as a field or activity\n"
    "  (e.g., 'i like data science', 'i study data science') — that is NOT an explicit job title.\n"
    "\n"
    "Never guess based on profile or prior chats—use the current message only.; when unsure about explicit DS role, leave ec_hit null."
)

INTENT_SCHEMA = {
    "name": "UIAIntent",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "employment_intent": {"type": "boolean"},
            "skills_intent": {"type": "boolean"},
            "ec_hit": {"type": ["string", "null"], "enum": ["ec_ds", None]},
            "confidence": {"type": "number", "minimum": 0, "maximum": 1}
        },
        "required": ["employment_intent", "skills_intent", "ec_hit", "confidence"]
    },
    "strict": True
}

def _coerce_bool(v) -> bool:
    return True if v is True else False

async def detect_intents_llm(message: str) -> Tuple[bool, bool]:
    comp = await client.chat.completions.create(
        model=DEFAULT_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": message},
        ],
        response_format={"type": "json_schema", "json_schema": INTENT_SCHEMA},
        temperature=0,
        timeout=REQUEST_TIMEOUT,
    )
    data = json.loads(comp.choices[0].message.content)
    return _coerce_bool(data["employment_intent"]), _coerce_bool(data["skills_intent"]), data["ec_hit"]
