from typing import List, Optional
from motor.motor_asyncio import AsyncIOMotorDatabase
from datetime import datetime
from app.db.init_db import CHAT_UIA_STATE

async def upsert_employment_category(db: AsyncIOMotorDatabase, chat_id: str, ec_id: str, vault_version: str):
    now = datetime.utcnow()
    # When EC changes, clear skills
    await db[CHAT_UIA_STATE].update_one(
        {"chat_id": chat_id},
        {"$set": {
            "employment_category_id": ec_id,
            "vault_version": vault_version,
            "updated_at": now
        },
         "$setOnInsert": {
            "recorded_at": now,
            "let_system_decide": False
        },
         "$unset": {"skills_selected": ""}},
        upsert=True
    )

async def get_chat_state(db: AsyncIOMotorDatabase, chat_id: str) -> dict | None:
    return await db[CHAT_UIA_STATE].find_one({"chat_id": chat_id}, {"_id": 0})

async def upsert_skills_selection(
    db: AsyncIOMotorDatabase,
    chat_id: str,
    employment_category_id: str,
    skills_selected: Optional[List[str]],
    let_system_decide: bool,
    vault_version: str
):
    now = datetime.utcnow()
    if let_system_decide:
        await db[CHAT_UIA_STATE].update_one(
            {"chat_id": chat_id},
            {"$set": {
                "employment_category_id": employment_category_id,
                "let_system_decide": True,
                "vault_version": vault_version,
                "updated_at": now
            },
             "$unset": {"skills_selected": ""}},
            upsert=True
        )
    else:
        await db[CHAT_UIA_STATE].update_one(
            {"chat_id": chat_id},
            {"$set": {
                "employment_category_id": employment_category_id,
                "skills_selected": skills_selected or [],
                "let_system_decide": False,
                "vault_version": vault_version,
                "updated_at": now
            }},
            upsert=True
        )