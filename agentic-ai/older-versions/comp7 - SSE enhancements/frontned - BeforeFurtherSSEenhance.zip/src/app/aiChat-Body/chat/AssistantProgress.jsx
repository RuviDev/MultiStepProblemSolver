import React from "react";

/**
 * Props:
 * - steps: string[]               // step labels
 * - active: number                // 0-based index of current step
 * - status: "running"|"done"|"error"
 */
export default function AssistantProgress({ steps = [], active = 0, status = "running" }) {
  return (
    <div className="w-full">
      {/* Header row with spinner / status */}
      <div className="flex items-center gap-2 text-sm mb-2">
        {status === "running" && (
          <span className="inline-block h-4 w-4 rounded-full border-2 border-gray-300 border-t-transparent animate-spin" />
        )}
        {status === "done" && (
          <span className="inline-block h-4 w-4 rounded-full bg-green-500" />
        )}
        {status === "error" && (
          <span className="inline-block h-4 w-4 rounded-full bg-red-500" />
        )}
        <span className="font-medium">
          {status === "running" && "Working on it…"}
          {status === "done" && "Done"}
          {status === "error" && "Something went wrong"}
        </span>
      </div>

      {/* Step list */}
      <ol className="space-y-1">
        {steps.map((label, i) => {
          const isDone = i < active || status === "done";
          const isCurrent = i === active && status === "running";
          return (
            <li key={i} className="flex items-start gap-2 text-sm">
              {/* Bullet */}
              <span
                className={[
                  "mt-1 inline-flex h-3 w-3 rounded-full",
                  isDone ? "bg-green-500" : isCurrent ? "bg-blue-500 animate-pulse" : "bg-gray-300",
                ].join(" ")}
                aria-hidden
              />
              {/* Label */}
              <span className={isDone ? "text-gray-700" : isCurrent ? "text-gray-900" : "text-gray-500"}>
                {label}
              </span>
            </li>
          );
        })}
      </ol>

      {/* Optional skeleton line to mimic ChatGPT’s typing area */}
      {status === "running" && (
        <div className="mt-3 h-3 w-40 rounded bg-gray-200/70 animate-pulse" />
      )}
    </div>
  );
}
