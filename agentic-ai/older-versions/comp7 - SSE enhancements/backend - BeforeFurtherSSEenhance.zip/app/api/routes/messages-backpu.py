from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Optional
import json, asyncio

from app.db.mongo import get_db
from app.api.deps import get_current_user
from app.core.security import decode_token
from app.services.progress import broker
from app.repositories.chats_repo import verify_chat_owner, touch_chat_activity
from app.repositories.messages_repo import list_messages as repo_list, insert_message
from app.repositories.vault_repo import get_active_vault_version
from app.api.routes.uia import intake as uia_intake_route, IntakeRequest

router = APIRouter(prefix="/messages", tags=["messages"])

@router.get("/{chat_id}")
async def list_messages(chat_id: str, user=Depends(get_current_user)):
    db = get_db()
    if not await verify_chat_owner(db, user["id"], chat_id):
        raise HTTPException(404, "Chat not found")
    return await repo_list(db, user["id"], chat_id)

class SendReq(BaseModel):
    prompt: str
    request_id: Optional[str] = None  # for progress tracking

@router.post("/{chat_id}")
async def send(chat_id: str, payload: SendReq, user=Depends(get_current_user)):
    db = get_db()
    if not await verify_chat_owner(db, user["id"], chat_id):
        raise HTTPException(404, "Chat not found")
    
    rid = payload.request_id or None
    async def step(i, label):
        await broker.publish(rid, {"type": "step", "index": i, "label": label})

    # 1) Save user message
    await step(0, "Queuing request")
    await insert_message(db, user["id"], chat_id, "user", content=payload.prompt)

    # 2) Call UIA intake (Component 06)
    await step(1, "Loading active vault")
    version = await get_active_vault_version(db)
    await step(2, "Detecting intent (LLM)")
    await step(3, "Checking chat state")
    uia_resp = await uia_intake_route(IntakeRequest(chat_id=chat_id, user_message=payload.prompt))
    print("UIA response:", uia_resp)

    # 3) Persist assistant message exactly as UIA intends
    if uia_resp.action in ("show_ec_survey", "show_skills_survey") and uia_resp.survey:
        await step(4, "Updating per-chat state")  # intake may have recorded EC
        await step(5, "Building the Survey")
        await insert_message(db, user["id"], chat_id, "assistant", content=None, type="survey", survey=uia_resp.survey)
        await touch_chat_activity(db, chat_id)
        # Return the survey message in UIA format to the frontend
        if uia_resp.action == "show_ec_survey":
            txt = f"Ok great, please select your employment category:"
        else:
            txt = "Ok great, please select your skills:"

        await broker.publish(rid, {"type": "done"})
        return { "role": "assistant", "type": "survey", "survey": uia_resp.survey, "content": txt }

    # For recorded_ec or none, turn into a small assistant text
    if uia_resp.action == "recorded_ec":
        txt = f"Noted your employment category: **{uia_resp.ec_id}**."
    elif uia_resp.action == "none":
        txt = "Thanks! (No identification action needed right now.)"
    else:
        txt = "Okay."

    await step(4, "Updating per-chat state")
    await step(5, "Preparing response")
    await insert_message(db, user["id"], chat_id, "assistant", content=txt)
    await touch_chat_activity(db, chat_id)

    await broker.publish(rid, {"type": "done"})
    return { "role": "assistant", "type": "text", "content": txt }

@router.get("/{chat_id}/progress")
async def stream_progress(chat_id: str, request: Request, request_id: str, access_token: str):
    """
    SSE: /messages/{chat_id}/progress?request_id=...&access_token=...
    """
    db = get_db()
    # validate token
    try:
        payload = decode_token(access_token)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid access token")
    user_id = payload.get("sub")
    if not await verify_chat_owner(db, user_id, chat_id):
        raise HTTPException(status_code=404, detail="Chat not found")

    queue = broker.get_queue(request_id)

    async def event_gen():
        # Initial no-op to open stream
        yield "event: open\ndata: {}\n\n"
        try:
            while True:
                # Allow heartbeats to keep connection alive
                try:
                    evt = await asyncio.wait_for(queue.get(), timeout=30)
                except asyncio.TimeoutError:
                    # Comment line = SSE heartbeat
                    yield ": keep-alive\n\n"
                    continue

                payload = json.dumps(evt)
                yield f"data: {payload}\n\n"

                if evt.get("type") in ("done", "error"):
                    break
        finally:
            broker.close(request_id)

    headers = {
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",  # for some proxies
    }
    return StreamingResponse(event_gen(), media_type="text/event-stream", headers=headers)