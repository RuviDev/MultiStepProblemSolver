from datetime import datetime
from typing import List, Literal, Optional
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from app.db.init_db import MESSAGES

Role = Literal["user", "assistant"]

async def list_messages(db: AsyncIOMotorDatabase, user_id: str, chat_id: str) -> List[dict]:
    cur = db[MESSAGES].find({"chat_id": ObjectId(chat_id), "user_id": ObjectId(user_id)}).sort("created_at", 1)
    out = []
    async for d in cur:
        m = {"role": d["role"], "type": d.get("type", "text"), "content": d.get("content", "")}
        if d.get("survey"): m["survey"] = d["survey"]
        out.append(m)
    return out

async def insert_message(db: AsyncIOMotorDatabase, user_id: str, chat_id: str,
                         role: Role, *, content: str | None, type: str = "text", survey: dict | None = None):
    doc = {
        "user_id": ObjectId(user_id),
        "chat_id": ObjectId(chat_id),
        "role": role,
        "type": type,
        "content": content or "",
        "survey": survey,
        "created_at": datetime.utcnow()
    }
    await db[MESSAGES].insert_one(doc)
