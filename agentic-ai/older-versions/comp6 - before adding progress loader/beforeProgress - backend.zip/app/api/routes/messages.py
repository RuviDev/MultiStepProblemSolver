from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from app.db.mongo import get_db
from app.api.deps import get_current_user
from app.repositories.chats_repo import verify_chat_owner, touch_chat_activity
from app.repositories.messages_repo import list_messages as repo_list, insert_message
from app.api.routes.uia import intake as uia_intake_route, IntakeRequest

router = APIRouter(prefix="/messages", tags=["messages"])

@router.get("/{chat_id}")
async def list_messages(chat_id: str, user=Depends(get_current_user)):
    db = get_db()
    if not await verify_chat_owner(db, user["id"], chat_id):
        raise HTTPException(404, "Chat not found")
    return await repo_list(db, user["id"], chat_id)

class SendReq(BaseModel):
    prompt: str

@router.post("/{chat_id}")
async def send(chat_id: str, payload: SendReq, user=Depends(get_current_user)):
    db = get_db()
    if not await verify_chat_owner(db, user["id"], chat_id):
        raise HTTPException(404, "Chat not found")

    # 1) Save user message
    await insert_message(db, user["id"], chat_id, "user", content=payload.prompt)

    # 2) Call UIA intake (Component 06)
    uia_resp = await uia_intake_route(IntakeRequest(chat_id=chat_id, user_message=payload.prompt))
    print("UIA response:", uia_resp)

    # 3) Persist assistant message exactly as UIA intends
    if uia_resp.action in ("show_ec_survey", "show_skills_survey") and uia_resp.survey:
        await insert_message(db, user["id"], chat_id, "assistant", content=None, type="survey", survey=uia_resp.survey)
        await touch_chat_activity(db, chat_id)
        # Return the survey message in UIA format to the frontend
        if uia_resp.action == "show_ec_survey":
            txt = f"Ok great, please select your employment category:"
        else:
            txt = "Ok great, please select your skills:"
        return { "role": "assistant", "type": "survey", "survey": uia_resp.survey, "content": txt }

    # For recorded_ec or none, turn into a small assistant text
    if uia_resp.action == "recorded_ec":
        txt = f"Noted your employment category: **{uia_resp.ec_id}**."
    elif uia_resp.action == "none":
        txt = "Thanks! (No identification action needed right now.)"
    else:
        txt = "Okay."

    await insert_message(db, user["id"], chat_id, "assistant", content=txt)
    await touch_chat_activity(db, chat_id)
    return { "role": "assistant", "type": "text", "content": txt }
