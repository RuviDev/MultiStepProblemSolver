// src/app/aiChat-Body/chat/welcome.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BRAIN } from "../../../assets";
import AskField from "../../../components/chat/AskField";
import AgentCardsSection from "../../../components/chat/AgentCardsSection";

// IMPORTANT: ensure this path matches your actual file name (MessageList.jsx)
import MessageList from "./messageList"; // or "./MessageList" if your file is PascalCase

// use the updated API helpers
import { messages as msgApi, chats, uia as uiaApi } from "../../../lib/api";

const Welcome = ({ chatId }) => {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([]);

  // Load history only when we have a chatId
  useEffect(() => {
    if (!chatId) return;
    (async () => {
      const history = await msgApi.list(chatId);
      // ⬇️ Preserve type & survey so the new MessageList can render surveys
      const normalized = history.map((m) => ({
        role: m.role,
        type: m.type || "text",
        content: m.content_md ?? m.content ?? "",
        survey: m.survey, // present when type === "survey"
      }));
      setMessages(normalized);
    })().catch(console.error);
  }, [chatId]);

  const append = (...rows) => setMessages((prev) => [...prev, ...rows]);

  // helper: update a specific temp progress bubble by _tempId
  const updateProgress = (tempId, updater) => {
    setMessages((prev) =>
      prev.map((m) => (m._tempId === tempId ? updater(m) : m))
    );
  };

  // helper: remove temp bubble
  const removeByTempId = (tempId) => {
    setMessages((prev) => prev.filter((m) => m._tempId !== tempId));
  };

  const handleSend = async ({ text }) => {
    if (!text?.trim()) return;

    // optimistic user message
    append({ role: "user", type: "text", content: text });

    // 1) Immediately show a progress bubble
    const tempId = `__progress__${Date.now()}`;
    const PROGRESS_STEPS = [
      "Queuing request",
      "Detecting intent (LLM)",
      "Loading active vault",
      "Checking chat state",
      "Updating per-chat state",
      "Preparing response",
    ];
    append({
      _tempId: tempId,
      role: "assistant",
      type: "progress",
      progress: { steps: PROGRESS_STEPS, active: 0, status: "running" },
    });

    // 2) Animate steps while the backend works (client-side only)
    let step = 0;
    const tickMs = 600; // feel free to tweak
    const timer = setInterval(() => {
      step = Math.min(step + 1, PROGRESS_STEPS.length - 1);
      updateProgress(tempId, (m) => ({
        ...m,
        progress: { ...m.progress, active: step },
      }));
    }, tickMs);

    try {
      let targetChatId = chatId;

      // If there's no chat yet, create one *but don't navigate yet*.
      if (!targetChatId) {
        const title = text.slice(0, 40);
        const created = await chats.create(title);
        targetChatId = created.id;

        // (Optional) Let the sidebar update immediately
        window.dispatchEvent(new CustomEvent("chats:refresh", { detail: { chat: created } }));
      }

      // Send while we’re still on the same page so the user sees their message.
      const asst = await msgApi.send(targetChatId, text);

      // Stop the loader and clean it up
      clearInterval(timer);
      removeByTempId(tempId);

      // Backend returns { role, type, content?, survey? } — push AS-IS
      append({
        role: asst.role || "assistant",
        type: asst.type || "text",
        content: asst.content ?? asst.content_md ?? "",
        survey: asst.survey,
      });

      // Now navigate to the chat route (no flicker because content is already visible)
      if (!chatId) {
        navigate(`/${targetChatId}`, { replace: true });
      }
    } catch (e) {
      console.error(e);

      clearInterval(timer);
      // flip loader to error state for a moment, then show an error bubble
      updateProgress(tempId, (m) => ({
        ...m,
        progress: { ...m.progress, status: "error" },
      }));
      // Optionally remove the error loader and show a clean error message
      setTimeout(() => removeByTempId(tempId), 400);
      
      append({ role: "assistant", type: "text", content: "Something went wrong reaching the server." });
    }
  };

  // === Survey submit handlers (Phase C) ===
  const handleSubmitEmployment = async ({ employment_category_id, vault_version }) => {
    try {
      await uiaApi.submitEmployment({
        chat_id: chatId, // important for per-chat UIA state
        employment_category_id,
        vault_version,
      });
      append({
        role: "assistant",
        type: "text",
        content: `Got it — employment category set to **${employment_category_id}**.`,
      });
    } catch (e) {
      append({
        role: "assistant",
        type: "text",
        content: `Couldn't save employment category: ${e?.message || "unknown error"}`,
      });
    }
  };

  const handleSubmitSkills = async ({ let_system_decide, skills_selected, employment_category_id, vault_version }) => {
    try {
      const res = await uiaApi.submitSkills({
        chat_id: chatId,
        employment_category_id,
        vault_version,
        let_system_decide,
        skills_selected,
      });

      append({
        role: "assistant",
        type: "text",
        content:
          res.mode === "system_decide"
            ? "Okay — the system will decide your skills plan."
            : `Nice — saved ${res.skills_count} skill(s).`,
      });
    } catch (e) {
      append({
        role: "assistant",
        type: "text",
        content: `Couldn't save skills: ${e?.message || "unknown error"}`,
      });
    }
  };

  const hasMessages = messages.length > 0;

  return hasMessages ? (
    <div className="h-full relative">
      <div className="h-full">
        <div className="mx-auto w-full max-w-3xl md:max-w-4xl h-full overflow-y-auto px-4 pt-4 pb-40">
          <MessageList
            messages={messages}
            chatId={chatId}
            onSubmitEmployment={handleSubmitEmployment}
            onSubmitSkills={handleSubmitSkills}
          />
        </div>
      </div>

      {/* Fixed input that offsets from sidebar width using CSS var */}
      <div className="fixed bottom-0 right-0" style={{ left: "var(--sbw, 0px)" }}>
        <div
          className="mx-auto w-full max-w-3xl md:max-w-4xl px-4 pb-6
                     bg-gradient-to-t from-white via-white/80 to-transparent
                     dark:from-[#0b0b0b] dark:via-[#0b0b0b]/80 dark:to-transparent"
        >
          <AskField onSend={handleSend} />
        </div>
      </div>
    </div>
  ) : (
    <div className="flex flex-col items-center justify-center w-full pt-8">
      <div className="flex items-center space-x-3">
        <img src={BRAIN} alt="Logo" className="h-10 object-contain" loading="eager" />
        <p className="text-2xl font-normal text-gray-900 dark:text-gray-100">
          Hi there, how can we help you ?
        </p>
      </div>

      <div className="w-full max-w-xl mt-8">
        <AskField onSend={handleSend} />
      </div>

      <div className="mt-10 max-w-2xl text-center">
        <p className="text-gray-500 dark:text-gray-400 text-base leading-relaxed">
          Drop your problem; the agents will plan, verify and execute.
        </p>
      </div>

      <AgentCardsSection />
    </div>
  );
};

export default Welcome;
