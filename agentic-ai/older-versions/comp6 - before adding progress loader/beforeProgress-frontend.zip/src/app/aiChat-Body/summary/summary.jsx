import React from 'react';

const Summary = () => {
    return (
        <div>
            {/* Summary content goes here */}
            Welcome to Summary!
        </div>
    );
}

export default Summary;
