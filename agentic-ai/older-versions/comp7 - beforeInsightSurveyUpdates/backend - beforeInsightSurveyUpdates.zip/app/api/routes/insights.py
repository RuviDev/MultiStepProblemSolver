# app/api/routes/insights.py
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.api.deps import get_current_user
from app.db.mongo import get_db
from app.services.insight_engine import stage01_auto_infer
from app.services.insight_survey import build_surveys, submit_survey
from app.models.insights import SurveySubmission

router = APIRouter(prefix="/insights", tags=["insights"])


class AutoInferRequest(BaseModel):
    chatId: str
    text: str


@router.get("/_health")
async def health():
    return {"status": "ok"}


@router.post("/auto-infer")
async def insights_auto_infer(
    req: AutoInferRequest,
    db: AsyncIOMotorDatabase = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Stage-01: run auto-inference → thresholds → batch expansion.
    Response includes pendingByBatch, insightStats, touchedBatchIds.
    """
    print("---------------------Auto-infer request:", req)
    result = await stage01_auto_infer(db, chatId=req.chatId, user_text=req.text)
    return result


@router.get("/pending/{chat_id}")
async def insights_pending(
    chat_id: str,
    db: AsyncIOMotorDatabase = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Stage-02: build per-batch micro-surveys for this chat (if any pending).
    """
    payloads = await build_surveys(db, chatId=chat_id)
    return payloads


@router.post("/submit")
async def insights_submit(
    submission: SurveySubmission,
    db: AsyncIOMotorDatabase = Depends(get_db),
    user=Depends(get_current_user),
):
    """
    Stage-02: submit survey responses. Survey wins (overrides Stage-01 if conflicts).
    Returns updated insightStats.
    """
    try:
        stats = await submit_survey(db, submission=submission)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    return {"insightStats": stats.model_dump()}
