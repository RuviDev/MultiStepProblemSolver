from datetime import datetime
from typing import List, Literal, Optional
from motor.motor_asyncio import AsyncIOMotorDatabase
from bson import ObjectId
from app.db.init_db import MESSAGES

from pydantic import BaseModel

Role = Literal["user", "assistant"]

async def list_messages(db: AsyncIOMotorDatabase, user_id: str, chat_id: str) -> List[dict]:
    cur = db[MESSAGES].find({"chat_id": ObjectId(chat_id), "user_id": ObjectId(user_id)}).sort("created_at", 1)
    out = []
    async for d in cur:
        m = {"role": d["role"], "type": d.get("type", "text"), "content": d.get("content", "")}
        if d.get("survey"): m["survey"] = d["survey"]
        out.append(m)
    return out

# async def insert_message(db: AsyncIOMotorDatabase, user_id: str, chat_id: str,
#                          role: Role, *, content: str | None, type: str = "text", survey: dict | None = None):
#     doc = {
#         "user_id": ObjectId(user_id),
#         "chat_id": ObjectId(chat_id),
#         "role": role,
#         "type": type,
#         "content": content or "",
#         "survey": survey,
#         "created_at": datetime.utcnow()
#     }
#     await db[MESSAGES].insert_one(doc)

def _bsonify(obj):
    # Convert Pydantic models (and any nested structures) to plain JSON-like values
    if isinstance(obj, BaseModel):
        return obj.model_dump()
    if isinstance(obj, (list, tuple)):
        return [_bsonify(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _bsonify(v) for k, v in obj.items()}
    return obj  # primitives pass through

async def insert_message(
    db: AsyncIOMotorDatabase,
    user_id: str,
    chat_id: str,
    role: str,
    *,
    content: str | None = None,
    type: str = "text",
    survey: object | None = None,
    blocks: object | None = None,
):
    doc = {
        "user_id": ObjectId(user_id),
        "chat_id": ObjectId(chat_id),
        "role": role,
        "type": type,
        "content": content or "",
        "created_at": datetime.utcnow(),
    }

    if survey is not None:
        doc["survey"] = _bsonify(survey)   # <-- convert here

    if blocks is not None:
        doc["blocks"] = _bsonify(blocks)   # <-- and here (future composite messages)

    await db[MESSAGES].insert_one(doc)
