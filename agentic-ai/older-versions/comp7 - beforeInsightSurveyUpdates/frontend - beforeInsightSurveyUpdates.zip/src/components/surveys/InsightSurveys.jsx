// import React, { useMemo, useState } from "react";
// import { insights as insightsApi } from "@/lib/api";
// import { Check, Send } from "lucide-react";

// /**
//  * props:
//  * - chatId: string
//  * - surveys: Array<{
//  *     batchId, title, language, ordering,
//  *     questions: [{ insightId, uiQuestion, type: "single"|"multi", options:[{answerId,label}], includeOther, noteOtherLabel }]
//  *   }>
//  * - onSubmitted?: (payload: { batchId, responses, insightStats? }) => void
//  * - submitter?: ({chatId, batchId, responses}) => Promise<any>   // DI for tests; defaults to API
//  */
// export default function InsightSurveys({ chatId, surveys, onSubmitted, submitter }) {
//   const submitFn = submitter || ((p) => insightsApi.submit(p));

//   if (!Array.isArray(surveys) || surveys.length === 0) {
//     return null;
//   }

//   return (
//     <div className="flex flex-col gap-6">
//       {surveys.map((batch) => (
//         <InsightBatchSurvey
//           key={batch.batchId}
//           chatId={chatId}
//           batch={batch}
//           onSubmitted={onSubmitted}
//           submitFn={submitFn}
//         />
//       ))}
//     </div>
//   );
// }

// function InsightBatchSurvey({ chatId, batch, onSubmitted, submitFn }) {
//   const [submitting, setSubmitting] = useState(false);
//   const [submitted, setSubmitted] = useState(false);

//   // selection state: { [insightId]: string | string[] }
//   const [sel, setSel] = useState({});

//   const questions = useMemo(() => {
//     // drop all "Other" text & options
//     const filterOther = (opts) => opts.filter((o) => !/^\s*other\b/i.test(o.label || ""));
//     return (batch.questions || []).map((q) => ({
//       ...q,
//       options: filterOther(q.options || []),
//     }));
//   }, [batch]);

//   const setSingle = (insightId, answerId) =>
//     setSel((s) => ({ ...s, [insightId]: answerId }));

//   const toggleMulti = (insightId, answerId) =>
//     setSel((s) => {
//       const prev = Array.isArray(s[insightId]) ? s[insightId] : [];
//       const exists = prev.includes(answerId);
//       const next = exists ? prev.filter((a) => a !== answerId) : [...prev, answerId];
//       return { ...s, [insightId]: next };
//     });

//   const buildResponses = () => {
//     const out = [];
//     for (const q of questions) {
//       const v = sel[q.insightId];
//       if (!v) continue;
//       if (q.type === "single" && typeof v === "string") {
//         out.push({ insightId: q.insightId, answerId: v });
//       } else if (q.type === "multi" && Array.isArray(v) && v.length > 0) {
//         out.push({ insightId: q.insightId, answerIds: v });
//       }
//     }
//     return out;
//   };

//   const handleSubmit = async () => {
//     const responses = buildResponses();
//     if (responses.length === 0) return; // nothing to submit
//     try {
//       setSubmitting(true);
//       const res = await submitFn({ chatId, batchId: batch.batchId, responses });
//       setSubmitted(true);
//       onSubmitted && onSubmitted({ batchId: batch.batchId, responses, ...res });
//     } finally {
//       setSubmitting(false);
//     }
//   };

//   return (
//     <div className="rounded-2xl border border-gray-200 p-4 shadow-sm bg-white">
//       <div className="flex items-center justify-between mb-3">
//         <div>
//           <div className="text-sm text-gray-500">{batch.language || "en"}</div>
//           <h3 className="text-lg font-semibold">{batch.title}</h3>
//         </div>
//         <button
//           onClick={handleSubmit}
//           disabled={submitting || submitted}
//           className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl text-sm
//             ${submitted ? "bg-green-600 text-white" : "bg-black text-white hover:bg-gray-800"}
//             disabled:opacity-60`}
//           title={submitted ? "Submitted" : "Submit this batch"}
//         >
//           {submitted ? <Check size={16} /> : <Send size={16} />}
//           {submitted ? "Submitted" : "Submit"}
//         </button>
//       </div>

//       {/* Questions horizontally scrollable */}
//       <div className="overflow-x-auto">
//         <div className="flex gap-4 pb-2">
//           {questions.map((q) => (
//             <QuestionCard
//               key={q.insightId}
//               q={q}
//               value={sel[q.insightId]}
//               onSingle={setSingle}
//               onMultiToggle={toggleMulti}
//             />
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }

// function QuestionCard({ q, value, onSingle, onMultiToggle }) {
//   return (
//     <div className="min-w-[320px] max-w-[360px] flex-shrink-0 rounded-xl border border-gray-200 p-4">
//       <div className="text-sm font-medium mb-3">{q.uiQuestion}</div>

//       {q.type === "single" ? (
//         <div className="flex flex-col gap-2">
//           {q.options.map((opt) => (
//             <label key={opt.answerId} className="inline-flex items-center gap-2 cursor-pointer">
//               <input
//                 type="radio"
//                 name={q.insightId}
//                 value={opt.answerId}
//                 checked={value === opt.answerId}
//                 onChange={() => onSingle(q.insightId, opt.answerId)}
//                 className="h-4 w-4"
//               />
//               <span className="text-sm">{opt.label}</span>
//             </label>
//           ))}
//         </div>
//       ) : (
//         <div className="flex flex-col gap-2">
//           {q.options.map((opt) => {
//             const checked = Array.isArray(value) && value.includes(opt.answerId);
//             return (
//               <label key={opt.answerId} className="inline-flex items-center gap-2 cursor-pointer">
//                 <input
//                   type="checkbox"
//                   value={opt.answerId}
//                   checked={checked}
//                   onChange={() => onMultiToggle(q.insightId, opt.answerId)}
//                   className="h-4 w-4"
//                 />
//                 <span className="text-sm">{opt.label}</span>
//               </label>
//             );
//           })}
//         </div>
//       )}
//     </div>
//   );
// }
