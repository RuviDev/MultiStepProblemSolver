// src/app/aiChat-Body/chat/InsightSurvey.jsx
import React from "react";
import InsightBatch from "./InsightBatch";

export default function InsightSurvey({ survey, chatId, onBatchSubmitted }) {
  const batches = survey?.batches || [];

  if (!batches.length) {
    return <div className="text-sm text-gray-500">No questions right now.</div>;
  }

  return (
    <div className="space-y-6">
      {batches.map((batch) => (
        <InsightBatch
          key={batch.batchId}
          chatId={chatId}
          batch={batch}
          onSubmitted={onBatchSubmitted}
        />
      ))}
    </div>
  );
}
