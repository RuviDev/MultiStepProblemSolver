// src/app/aiChat-Body/chat/AssistantProgress.jsx
import React from "react";

/**
 * Props:
 * - currentLabel: string
 * - status: "running" | "done" | "error"
 */
export default function AssistantProgress({ currentLabel = "Working…", status = "running" }) {
  return (
    <div className="flex items-center gap-3 text-sm">
      {status === "running" && (
        <span className="inline-block h-4 w-4 rounded-full border-2 border-gray-300 border-t-transparent animate-spin" />
      )}
      {status === "done" && <span className="inline-block h-3 w-3 rounded-full bg-green-500" aria-hidden />}
      {status === "error" && <span className="inline-block h-3 w-3 rounded-full bg-red-500" aria-hidden />}

      <div className="flex flex-col">
        <div className="font-medium">
          {status === "running" ? "Working on it…" : status === "done" ? "Done" : "Something went wrong"}
        </div>
        <div className="text-gray-600 text-xs">{currentLabel}</div>
      </div>
    </div>
  );
}
