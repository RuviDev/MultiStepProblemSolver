import LOGO from "./logos/Project name.png";
import AGENT from "./icons/agents.png";
import BRAIN from "./icons/Brain.png";
import CHAT from "./icons/chat.png";
import LOGO_TRANSPARENT_CENTER from "./icons/logo_transparent_center.png";
import NEWCHAT from "./icons/New chat.png";
import SETTINGS from "./icons/settings.png";
import SIDEBAR from "./icons/sidebar.png";
import YOURPROJECT from "./icons/Your projects.png";
export {
  LOGO,
  AGENT,
  BRAIN,
  CHAT,
  LOGO_TRANSPARENT_CENTER,
  NEWCHAT,
  SETTINGS,
  SIDEBAR,
  YOURPROJECT,
};
