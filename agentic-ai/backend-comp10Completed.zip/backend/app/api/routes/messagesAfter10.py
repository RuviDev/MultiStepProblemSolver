from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import Callable, Optional, Dict, Any
import json, asyncio
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel

from app.db.mongo import get_db
from app.api.deps import get_current_user
from app.core.security import decode_token
from app.services.progress import broker
from app.repositories.chats_repo import verify_chat_owner, touch_chat_activity
from app.repositories.messages_repo import list_messages as repo_list, insert_message
from app.repositories.vault_repo import get_active_vault_version
from app.api.routes.uia import intake as uia_intake_route, IntakeRequest
from app.services.insight_engine import stage01_auto_infer
from app.services.insight_survey import build_surveys
from app.components.component10 import component10

router = APIRouter(prefix="/messages", tags=["messages"])

# ------------------ Helper functions ------------------

def _bsonify(obj):
    # Convert Pydantic models (and any nested structures) to plain JSON-like values
    if isinstance(obj, BaseModel):
        return obj.model_dump()
    if isinstance(obj, (list, tuple)):
        return [_bsonify(x) for x in obj]
    if isinstance(obj, dict):
        return {k: _bsonify(v) for k, v in obj.items()}
    return obj  # primitives pass through

def make_stepper(rid: Optional[str]) -> Callable[[int, str], Any]:
    """
    Returns an async function step(index:int, label:str) that publishes SSE progress.
    If rid is None, it's a no-op (safe to call).
    """
    async def step(index: int, label: str):
        if rid:
            await broker.publish(rid, {"type": "step", "label": label})
    return step

async def component6(
    db,
    *,
    chat_id: str,
    user_id: str,
    prompt: str,
    step: Callable[[int, str], Any],
) -> Dict[str, Any]:
    """
    Runs Component 06 (UIA) with server-driven progress steps and prepares
    the assistant message payload (without persisting it).

    Returns a dict with:
      - "uia_action": str   ("show_ec_survey" | "show_skills_survey" | "recorded_ec" | "none" | other)
      - "assistant_msg": dict  # {role, type, content?, survey?} ready to be returned & persisted
      - "persist_kind": str    # "survey" or "text"
    """
    print(" ---------------------------------------------------- ")
    print(f" ----| Starting Component 6 |")

    # C06 steps (1..5) — keep indices aligned with your timeline
    _version = await get_active_vault_version(db)

    await step(1, "Detecting intent (LLM)")
    uia_resp = await uia_intake_route(IntakeRequest(chat_id=chat_id, user_message=prompt))

    if uia_resp.action in ("show_ec_survey", "show_skills_survey") and uia_resp.survey:
        await step(2, "Building the Surveys")

        if uia_resp.action == "show_ec_survey":
            content_txt = "Ok great, please select your employment category:"
        else:
            content_txt = "Ok great, please select your skills:"

        assistant_msg = {
            "role": "assistant",
            "type": "survey",
            "survey": uia_resp.survey,
            "content": content_txt,  # you were already returning this alongside the survey
        }
        return {
            "uia_action": uia_resp.action,
            "assistant_msg": assistant_msg,
            "persist_kind": "survey",
        }

    # If no survey: produce a small text acknowledgement
    if uia_resp.action == "recorded_ec":
        txt = f"Noted your employment category: **{uia_resp.ec_id}**."
    elif uia_resp.action == "none":
        txt = "Thanks! (No identification action needed right now.)"
    else:
        txt = "Okay."

    await step(2, "Updating per-chat state")

    assistant_msg = {
        "role": "assistant",
        "type": "text",
        "content": txt,
    }

    print(f" ----| Component 6 done | action={uia_resp.action} |")
    print(" ---------------------------------------------------- ")
    print()

    return {
        "uia_action": uia_resp.action,
        "assistant_msg": assistant_msg,
        "persist_kind": "text",
    }

async def component7(
    db,
    *,
    chat_id: str,
    user_id: str,
    prompt: str,
    step: Callable[[int, str], Any],
) -> Dict[str, Any]:
    """
    Runs Component 07 (Insights) immediately after Component 06.
    Emits progress via the shared step() helper.

    Returns a dict with a compact summary:
      - "autoTakenCount", "questionOnlyCount"
      - "touchedBatchIds", "pendingByBatch"
      - "surveysPrepared": int
    """

    print(" ---------------------------------------------------- ")
    print(f" ----| Starting Component 7 |")

    # Suggested indices for C07 to follow C06 (which used 1..5)
    await step(3, "Insights: Stage-01 starting")
    print("### Stage 1: Auto Inference")
    result = await stage01_auto_infer(db, chatId=chat_id, user_text=prompt)

    auto_taken = int(result.get("autoTakenCount", 0))
    question_only = int(result.get("questionOnlyCount", 0))
    await step(4, f"Insights: Auto-inference done (auto-taken: {auto_taken})")

    touched = result.get("touchedBatchIds", []) or []
    pending_map = result.get("pendingByBatch", {}) or {}
    pending_total = sum(len(v) for v in pending_map.values())
    # await step(8, f"Insights: Batch expansion across {len(touched)} batch(es); pending {pending_total} item(s)")

    print()
    print("### Stage 2: Building surveys (if any pending)")
    surveys = await build_surveys(db, chatId=chat_id)
    batches = surveys.batches or []

    print("-"*20)
    print(f"--- Built survey(s) for chat {chat_id}: {surveys}")
    print("-"*20)

    if surveys:
        q_count = sum(len(b.questions) for b in batches)     # count questions across batches
        batch_count = len(batches)
        await step(5, f"Insights: Follow-up surveys ready ({q_count} question(s)) in {batch_count} batch(es)")
    else:
        await step(5, "Insights: No follow-ups needed right now")

    content_txt = "Insiight Survey"

    assistant_msg = {
        "role": "assistant",
        "type": "insight-survey",
        "survey": _bsonify(surveys),
        "content": content_txt,  # you were already returning this alongside the survey
    }

    return {
        "autoTakenCount": auto_taken,
        "questionOnlyCount": question_only,
        "touchedBatchIds": touched,
        "pendingByBatch": pending_map,
        "surveysPrepared": batch_count,
        "assistant_msg": assistant_msg,
    }

# ------------------ Message listing and sending ------------------

@router.get("/{chat_id}")
async def list_messages(chat_id: str, user=Depends(get_current_user)):
    db = get_db()
    if not await verify_chat_owner(db, user["id"], chat_id):
        raise HTTPException(404, "Chat not found")
    return await repo_list(db, user["id"], chat_id)

class SendReq(BaseModel):
    prompt: str
    request_id: Optional[str] = None  # for progress tracking

@router.post("/{chat_id}")
async def send(chat_id: str, payload: SendReq, user=Depends(get_current_user)):
    db = get_db()
    if not await verify_chat_owner(db, user["id"], chat_id):
        raise HTTPException(404, "Chat not found")
    
    print("====================================================")
    print(f" --| New message in chat {chat_id} from user {user['id']}: {payload.prompt[:50]}...")
    print()

    rid = payload.request_id or None
    step = make_stepper(rid)

    try:
        # 0) Save user message (outside C06)
        await step(0, "Queuing request")
        await insert_message(db, user["id"], chat_id, "user", content=payload.prompt)

        # ---- Component 06 (UIA) ----
        c06 = await component6(
            db,
            chat_id=chat_id,
            user_id=user["id"],
            prompt=payload.prompt,
            step=step,
        )

        # 6) Persist exactly what Component 06 prepared
        if c06["persist_kind"] == "survey":
            await insert_message(db, user["id"], chat_id, "assistant", content=c06["assistant_msg"]["content"], type="survey", survey=c06["assistant_msg"]["survey"],
            )
        else:
            await insert_message(db, user["id"], chat_id, "assistant", content=c06["assistant_msg"]["content"], type="text",
            )

        await touch_chat_activity(db, chat_id)

        # ---- Component 07 (Insights) ----
        c07 = await component7(
            db,
            chat_id=chat_id,
            user_id=user["id"],
            prompt=payload.prompt,
            step=step,
        )


        print("=="*30)
        print(f" ----| Component 6 result: {c06}")
        print("=="*30)
        print(f" ----| Component 7 result: {c07}")
        print("=="*30)

        enc = await component10(
            db,
            chat_id=chat_id,
            user_id=user["id"],
            user_msg=payload.prompt,
            c06=c06,
            c07=c07,
            step=step,
        )

        print(f" ----| Component 10 result: {enc}")

        await broker.publish(rid, {"type": "done"})

        print()
        print(" --| Message processing complete |")
        print("====================================================")

        if c06["assistant_msg"]["type"] == "text" and c07["surveysPrepared"] > 0:
            await insert_message(db, user["id"], chat_id, "assistant", content=None, type="insight-survey", survey=c07["assistant_msg"]["survey"],
            )
            return c07["assistant_msg"]
        
        return c06["assistant_msg"]

    except Exception as e:
        # surface an SSE error event for the loader
        await broker.publish(rid, {"type": "error", "message": "Processing failed"})
        raise

@router.get("/{chat_id}/progress")
async def stream_progress(chat_id: str, request: Request, request_id: str, access_token: str):
    """
    SSE: /messages/{chat_id}/progress?request_id=...&access_token=...
    """
    db = get_db()
    # validate token
    try:
        payload = decode_token(access_token)
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid access token")
    user_id = payload.get("sub")
    if not await verify_chat_owner(db, user_id, chat_id):
        raise HTTPException(status_code=404, detail="Chat not found")

    queue = broker.get_queue(request_id)

    async def event_gen():
        # Initial no-op to open stream
        yield "event: open\ndata: {}\n\n"
        try:
            while True:
                # Allow heartbeats to keep connection alive
                try:
                    evt = await asyncio.wait_for(queue.get(), timeout=30)
                except asyncio.TimeoutError:
                    # Comment line = SSE heartbeat
                    yield ": keep-alive\n\n"
                    continue

                payload = json.dumps(evt)
                yield f"data: {payload}\n\n"

                if evt.get("type") in ("done", "error"):
                    break
        finally:
            broker.close(request_id)

    headers = {
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",  # for some proxies
    }
    return StreamingResponse(event_gen(), media_type="text/event-stream", headers=headers)